import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  //await page.goto('about:blank');
  //await page.goto('chrome-error://chromewebdata/');
  await page.goto('https://uat.identity.nielseniq.io/oauth2/default/v1/authorize?response_type=code&scope=openid%20profile%20email%20offline_access&client_id=0oa3jtkhbiQl2okQa1d7&state=8mqa7uaZ_HvWRZK7s-s_ms1FE6k&redirect_uri=https%3A%2F%2Finfinetqc.spectrainfinet.com%2Foidc&nonce=A9pft-gfTxu845lLwBnhYP_H5Qhp8CG3FuRzbk2ejTw');
  await page.getByLabel('Username').click();
  await page.getByLabel('Username').fill('spectraautomationtest@nielseniq.com');
  await page.getByRole('button', { name: 'Next' }).click();
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('Bbsr@2021');
  await page.getByRole('button', { name: 'Verify' }).click();
  await page.waitForTimeout(5000);
  await page.click("#CREATEASSETS");
  await page.frameLocator('iframe[name="ac_contentFrame"]').getByText('Application and Data Package').click();
  await page.goto('https://infinetqc.spectrainfinet.com/servlet/ac?action=portfolioId&param=adminutils');
  await page.frameLocator('iframe[name="ac_contentFrame"]').getByText('Admin Utilities').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="frameADMINUTILS"]').getByRole('cell', { name: 'Client Login' }).click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').locator('#clientId').selectOption('spectratest');
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').getByRole('button', { name: 'Submit' }).click();
  await page.getByRole('cell', { name: 'United States (English)', exact: true }).click();
  await page.getByText('Mexico (English)').click();
});