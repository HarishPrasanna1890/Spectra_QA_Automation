import {test, expect} from '@playwright/test'

test('Assertions-test', async ({page})=>{

    await page.goto('https://demo.nopcommerce.com/register');

    await expect(page).toHaveURL('https://demo.nopcommerce.com/register');

    await expect(page).toHaveTitle('nopCommerce demo store. Register');

    const logoElement = await page.locator('.header-logo');
    await expect(logoElement).toBeVisible();
    
    await expect(await page.locator('.page-title h1')).toHaveText('Register');

    await expect (await page.locator('.page-title h1')).toContainText('Reg');

})