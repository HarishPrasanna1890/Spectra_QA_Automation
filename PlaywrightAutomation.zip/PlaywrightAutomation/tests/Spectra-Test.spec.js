import { test, expect } from '@playwright/test';

test('Spectra test', async ({ page })=>{

    await page.goto("https://infinettest.spectrainfinet.com/servlet/ac");
    //await page.waitForTimeout(3000);
    await page.fill('#input27','spectraautomationtest@nielseniq.com');
    await page.click('[type=submit]');
    await page.fill("input[type='password']",'Bbsr@2021');
    await page.click('[type=submit]');
    //await page.waitForTimeout(10000);
   // await expect(page).toHaveTitle('Spectra');
    //await page.click("#CREATEASSETS");
    await page.locator("//td[@id='LOCATION']").click();
    await page.locator("//div[normalize-space()='United States (English)']").click();
    //await page.click("#button-1012-btnInnerEl");
    await page.click("#CREATEASSETS");
    //await page.locator("//h1[normalize-space()='Reports']").click();
    //const allFrames = await page.frames();
   // console.log("Number of frames", allFrames.length);
    //const frameUrl = await page.frame({url:'https://infinettest.spectrainfinet.com/answercenter/acui.jsp'});
   // await frameUrl.locator("//td[@id='explorerTitleREPORT']").click();

   let frame1 = await page.frameLocator('#ac_contentFrame').locator("//td[@id='explorerTitleREPORT']")
  await frame1.click();
   //await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="frameREPORT"]')
  // .getByRole('link', { name: 'Account Area Definition' }).click();
   await frame1.click("//a[normalize-space()='Account Area Definition']");

   await page.frameLocator('iframe[name="ac_viewerFrame"]')
   .frameLocator('#content-frame').getByText('Beauty Care Stores').click();

   //let frame2 = await page.frameLocator('ac_viewerFrame').locator("//td[@id='explorerTitleREPORT']")


    //await page.click("//td[@id='explorerTitleREPORT']");
    //await page.click("//a[normalize-space()='Account Area Definition']");
    //await page.waitForTimeout(30000);
    //await page.locator("//td[contains(text(),'Welcome,')]").
    //await page.click("//a[contains(text(),'Best')]");
    //await page.pause();
``
})