const {test, expect} = require('@playwright/test')

test('LocatingMultipleElements', async ({page})=>{

    await page.goto('https://www.demoblaze.com/index.html');

    /* const AllLinks = await page.$$('a'); //Return all the links on the page.
    for(const link of AllLinks)
    {
        const linkText = await link.textContent();
        console.log(linkText);
    } */
    page.waitForSelector("//div[@id='tbodyid']//h4/a");
   const AllProducts = await page.$$("//div[@id='tbodyid']//h4/a");

   for( const product of AllProducts)
   {
        const ProductName = await product.textContent();
        console.log(ProductName);
   }
})