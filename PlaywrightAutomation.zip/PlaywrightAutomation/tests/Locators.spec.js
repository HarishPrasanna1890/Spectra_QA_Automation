//const {test, expect} = require('@playwright/test');
import {test, expect} from '@playwright/test'

test('Locators', async ({page})=>{

await page.goto('https://www.demoblaze.com/index.html');

//Click on login button - Using property
//await page.locator('id=login2').click();
await page.click('id=login2');

//Enter username - Using CSS
await page.fill('#loginusername','pavanol')
//await page.type('#loginusername','harishtest')

//Enter Password - Using CSS
await page.fill("input[id='loginpassword']",'test@123')

//Click on login button - Xpath
await page.click("//button[normalize-space()='Log in']")

//verify logout link presence - xpath
const LogOutLink = await page.locator("//a[@id='logout2']");

await expect(LogOutLink).toBeVisible();

await page.close();


})