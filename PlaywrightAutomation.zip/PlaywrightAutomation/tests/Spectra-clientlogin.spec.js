import { test, expect } from '@playwright/test';

test('Spectra test', async ({ page })=>{

    await page.goto("https://infinettest.spectrainfinet.com/servlet/ac");
    //await page.waitForTimeout(3000);
    await page.fill('#input27','spectraautomationtest@nielseniq.com');
    await page.click('[type=submit]');
    await page.fill("input[type='password']",'Bbsr@2021');
    await page.click('[type=submit]');

    const FramesCount = page.frames();
    console.log('No.of frames: ', +FramesCount.length);
    //await page.waitForTimeout(10000);
   // await expect(page).toHaveTitle('Spectra');
    await page.click("#CREATEASSETS");
    await page.waitForLoadState();
    //await page.locator("//td[@id='LOCATION']").click();
   // await page.locator("//div[normalize-space()='United States (English)']").click();
    const frame1 = page.frame('#ac_contentFrame').locator("//td[@id='explorerTitleADMINUTILS']");
    await frame1.click();
    await page.waitForLoadState();
    

   /*  const frame2 = page.frame("#frameADMINUTILS").locator("//td[contains(text(),'Client Login')]");
    await frame2.click();
    await page.waitForLoadState();*/

   // const childFrames = frame1.frameLocator('#frameADMINUTILS');
   // await childFrames.locator("//td[contains(text(),'Client Login')]").click();


    //await page.locator("//td[@id='explorerTitleADMINUTILS']").click();
    //const frame2 = page.frameLocator("#frameADMINUTILS").locator("//td[contains(text(),'Client Login')]");
    //locator("//td[contains(text(),'Client Login')]");
    //await frame2.click({ force: true });
    
    
    

    //const frame2 = await page.frameLocator('#framePORTFOLIO')
    //await page.selectOption('#portfolioId','Admin Utilities');
    
    

    
    

})