import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://uat.identity.nielseniq.io/oauth2/default/v1/authorize?response_type=code&scope=openid%20profile%20email%20offline_access&client_id=0oa3a6k7rs034VbaX1d7&state=5JduW_0E7Q_gVO4BII_UlTE0rKo&redirect_uri=https%3A%2F%2Finfinettest.spectrainfinet.com%2Foidc&nonce=N_oR3ltvnl7r47GIZqQWzg8rvsPCuitWSVYdftyub1Y');
  await page.getByLabel('Username').fill('spectraautomationtest@nielseniq.com');
  await page.getByRole('button', { name: 'Next' }).click();
  await page.getByLabel('Password').click();
  await page.getByLabel('Password').fill('Bbsr@2021');
  await page.getByRole('button', { name: 'Verify' }).click();
  await page.getByRole('cell', { name: 'Create Content', exact: true }).click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').getByText('Reports').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="frameREPORT"]').getByRole('link', { name: 'Account Area Definition' }).click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').getByText('Beauty Care Stores').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#button-1036-btnEl').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#ext-gen1176 span').first().click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#ext-gen1196 span').first().click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#ext-gen1224 span').first().click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#ext-gen1253').getByText('Beauty Care Stores').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').locator('#button-1074-btnEl').click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').getByRole('button', { name: 'Next' }).click();
  await page.frameLocator('iframe[name="ac_contentFrame"]').frameLocator('iframe[name="ac_viewerFrame"]').frameLocator('#content-frame').getByRole('button', { name: 'Submit' }).click();
});