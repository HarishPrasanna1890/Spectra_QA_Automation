package com.leafBot.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;




public class MyHomePage extends ProjectSpecificMethods {

	public MyHomePage(RemoteWebDriver driver, ExtentTest node){
		this.driver = driver;
		this.node = node;
				
	}
//click leads
	public MyLeadsPage clickLeadLink(){
		click(locateElement("link","Leads"));
		return new MyLeadsPage(driver, node);
	}
	
	public ContactsLeadPage clickContactLeads() throws InterruptedException {
		click(locateElement("link", "Contacts"));
		Thread.sleep(3000);
		return new ContactsLeadPage(driver, node);
	}

	public CasesPage clickCasesLink() throws InterruptedException {
		click(locateElement("link", "Cases"));
		Thread.sleep(3000);
		return new CasesPage(driver, node);
	}
}
