package com.leafBot.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class EditContactLeadPage extends ProjectSpecificMethods{

	public EditContactLeadPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node= node;
	}
	
	public EditContactLeadPage EditFirstContactName() {
		clearAndType(locateElement("id","updateContactForm_firstName"),"Harish");
		return this;	
	}
	
	public EditContactLeadPage EditSecondContactName() {
		clearAndType(locateElement("id","updateContactForm_lastName"),"A");
		return this;
		
	}
	
	public ViewLeadPage clickEditContactSubmit(){
		click(locateElement("xpath","(//input[@class='smallSubmit'])[1]"));
		return new ViewLeadPage(driver, node);
	}

}
