package com.leafBot.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class ViewContactLeadPage extends ProjectSpecificMethods{

	public ViewContactLeadPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node= node;
	}
	
	public EditContactLeadPage clickEditbtn(){
		click(locateElement("xpath","(//div[@class='frameSectionExtra']/a)[1]"));
		return new EditContactLeadPage(driver, node);
	}
	

}
