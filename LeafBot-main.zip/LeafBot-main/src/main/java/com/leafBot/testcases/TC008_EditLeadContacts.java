package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class TC008_EditLeadContacts extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setValues() {
		testCaseName = "Edit Contact Lead";
		testDescription = "Get the contact and edit it with new first name and last name";
		nodes = "Leads";
		authors = "Harish";
		category = "Smoke";
		dataSheetName = "TC008";
	}

	@Test(dataProvider = "fetchData")
	public void EditContactLead(String uName, String pwd) throws InterruptedException {
		
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickCRMSFA()
		.clickContactLeads()
		.clickFirstResultingLead()
		.clickEditbtn()
		.EditFirstContactName()
		.EditSecondContactName()
		.clickEditContactSubmit();
		
		
	}
}
