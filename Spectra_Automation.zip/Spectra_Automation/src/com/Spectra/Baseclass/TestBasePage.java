package com.Spectra.Baseclass;

import org.openqa.selenium.WebDriver;



public class TestBasePage {
	//private static String fileSeperator = System.getProperty("file.separator");
	public static String screenPath = System.getProperty("screenshots");;
	public static WebDriver driver;
	public String browser="Chrome";
	//public PropertyFileManager properties = null;
}