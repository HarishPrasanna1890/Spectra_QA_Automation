package com.Spectra_Testscripts;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginClientsApplication {

	public static void main(String[] args) throws InterruptedException {
		
		//1. setup the browser driver
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
        //2. instantiate the browser driver
        WebDriver driver = new ChromeDriver();
        //3. perform the operations
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, 10);	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.get("https://infinetqc.spectrainfinet.com/servlet/ac");
        driver.findElement(By.id("input27")).sendKeys("spectraautomationtest@nielseniq.com");
        driver.findElement(By.cssSelector("[type=submit]")).click();
        driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Bbsr@2021");
        driver.findElement(By.cssSelector("[type=submit]")).click();
        Thread.sleep(3000);
//		
			WebElement Specta_Menu_option=driver.findElement(By.id("CREATEASSETS"));
			
			Specta_Menu_option.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
			driver.switchTo().frame("ac_contentFrame");
			WebElement Application_dataPackage=driver.findElement(By.id("imgPORTFOLIO"));		
			Application_dataPackage.click();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("framePORTFOLIO")));
			driver.switchTo().frame("framePORTFOLIO");
			Select application=new Select(driver.findElement(By.id("portfolioId")));
			application.selectByVisibleText("Admin Utilities");
			
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='ac_contentFrame']")));
			WebElement imgADMINUTILS=driver.findElement(By.id("imgADMINUTILS"));		
			imgADMINUTILS.click();
			
			
		
	
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe[@id='frameADMINUTILS']")));
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='frameADMINUTILS']")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'Client Login')]")));
			WebElement Client_Login_link=driver.findElement(By.xpath("//td[contains(text(),'Client Login')]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Client_Login_link);
			Thread.sleep(500); 
			Client_Login_link.click();
			//driver.switchTo().defaultContent();
			
			driver.switchTo().defaultContent();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
			driver.switchTo().frame("ac_contentFrame");
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_viewerFrame")));
			driver.switchTo().frame("ac_viewerFrame");
			WebElement select_Client=driver.findElement(By.id("clientId"));
			Select sc=new Select(select_Client);
			sc.selectByVisibleText("SpectraTest2");
			
			WebElement select_Client_submit=driver.findElement(By.id("okBtn"));
			select_Client_submit.click();
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CREATEASSETS")));
			WebElement Specta_Menu_option1=driver.findElement(By.id("CREATEASSETS"));
			Specta_Menu_option1.click();
			
			/*Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
			driver.switchTo().frame("ac_contentFrame");		
	//		Application_dataPackage.click();
			
			Thread.sleep(6000);
			if (driver.findElement(By.xpath("//a[contains(text(),'Account Area Definition')]")).isDisplayed()) {
				driver.findElement(By.xpath("//a[contains(text(),'Account Area Definition')]")).click();
		     } */
		}
		
		/*Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("framePORTFOLIO")));
		driver.switchTo().frame("framePORTFOLIO");
		//Get all options
	    List<WebElement> dd = application.getOptions();
	    //Get the length
	    System.out.println(dd.size());

	    // Loop to print one by one
	    for (int j = 0; j < dd.size(); j++) {
	        System.out.println(dd.get(j).getText());

	    }
	*/
		
		
	/*	System.out.print("pass");
		}
		catch(Exception e){
			 
			System.out.println(e);
	 
		}
		
		finally{
			driver.quit();
			
		} */
		
	

}

