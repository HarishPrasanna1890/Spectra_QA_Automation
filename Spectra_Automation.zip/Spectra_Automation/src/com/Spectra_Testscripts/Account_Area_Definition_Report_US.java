package com.Spectra_Testscripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Account_Area_Definition_Report_US {

	public static void main(String[] args) throws InterruptedException {
		//1. setup the browser driver
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
        //2. instantiate the browser driver
        WebDriver driver = new ChromeDriver();
        //3. perform the operations
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, 10);	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.get("https://infinetqc.spectrainfinet.com/servlet/ac");
        driver.findElement(By.id("input27")).sendKeys("spectraautomationtest@nielseniq.com");
        driver.findElement(By.cssSelector("[type=submit]")).click();
        driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Bbsr@2021");
        driver.findElement(By.cssSelector("[type=submit]")).click();
        Thread.sleep(3000);
        WebElement Spectra_Menu_option=driver.findElement(By.id("CREATEASSETS"));
        Spectra_Menu_option.click();
        Thread.sleep(3000);
        //Main frame
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		WebElement Application_dataPackage=driver.findElement(By.id("imgPORTFOLIO"));		
		Application_dataPackage.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("framePORTFOLIO")));
		driver.switchTo().frame("framePORTFOLIO");
		Select application=new Select(driver.findElement(By.id("portfolioId")));
		application.selectByVisibleText("Admin Utilities");
		
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		WebElement imgADMINUTILS=driver.findElement(By.id("imgADMINUTILS"));		
		imgADMINUTILS.click();
		
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe[@id='frameADMINUTILS']")));
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='frameADMINUTILS']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'Client Login')]")));
		WebElement Client_Login_link=driver.findElement(By.xpath("//td[contains(text(),'Client Login')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Client_Login_link);
		Thread.sleep(500); 
		Client_Login_link.click();
		
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_viewerFrame")));
		driver.switchTo().frame("ac_viewerFrame");
		WebElement select_Client=driver.findElement(By.id("clientId"));
		Select sc=new Select(select_Client);
		sc.selectByVisibleText("SpectraTest2");
		
		WebElement select_Client_submit=driver.findElement(By.id("okBtn"));
		select_Client_submit.click();
		
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
		wait.ignoring(StaleElementReferenceException.class).until(
        ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.id("CREATEASSETS"))));	
		WebElement Spectra_Menu_option1=driver.findElement(By.id("CREATEASSETS"));
        Spectra_Menu_option1.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		WebElement Application_dataPackage1=driver.findElement(By.id("imgPORTFOLIO"));		
		Application_dataPackage1.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("framePORTFOLIO")));
		driver.switchTo().frame("framePORTFOLIO");
		Select application1=new Select(driver.findElement(By.id("portfolioId")));
		application1.selectByVisibleText("Spectra");
		Thread.sleep(3000);
		
		driver.switchTo().defaultContent();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		WebElement Application_dataPackage2=driver.findElement(By.id("imgPORTFOLIO"));		
		Application_dataPackage2.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_viewerFrame")));
		driver.switchTo().frame("ac_viewerFrame");
		
		WebElement Account_Area_link=driver.findElement(By.xpath("//a[text()='Account Area Definition']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Account_Area_link);
		Thread.sleep(5000); 
		Account_Area_link.click();
		
		driver.switchTo().defaultContent();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		WebElement Application_dataPackage3=driver.findElement(By.id("imgPORTFOLIO"));		
		Application_dataPackage3.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_viewerFrame")));
		driver.switchTo().frame("ac_viewerFrame");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("content-frame")));
		driver.switchTo().frame("content-frame");
		
		//Double click
		WebElement mass_Merchandiser = driver.findElement(By.xpath("//span[text()='Mass Merchandiser Stores']"));
		Actions act = new Actions(driver);
		act.doubleClick(mass_Merchandiser).perform();
		
		WebElement clickSupplier =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Supplier']")));
		Actions act1 = new Actions(driver);
		act1.doubleClick(clickSupplier).perform();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'99 Cents Only Stores / Commerce CA (Mass Merchandiser Suppliers)')]")));
		driver.findElement(By.xpath("//span[contains(text(),'99 Cents Only Stores / Commerce CA (Mass Merchandiser Suppliers)')]")).click();
		driver.findElement(By.xpath("(//div[@id='hierarchyChooserContainer_compForm:GTIDS']//span[contains(@id,'btnInnerEl')])[6]")).click();
		//99 Cents Only Stores / Commerce CA (Mass Merchandiser Suppliers)
		
		//next
		driver.findElement(By.id("btn_next")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("compForm:REFTARGETGTL")));
		WebElement select_State=driver.findElement(By.id("compForm:REFTARGETGTL"));
		Select sc1=new Select(select_State);
		sc1.selectByVisibleText("State");
		//Next button
		driver.findElement(By.id("btn_next")).click();
		
		driver.findElement(By.id("compForm:RPTNAME")).sendKeys("Account Area Definition");
		driver.findElement(By.id("compForm:RPTEMAIL:0")).click();
		driver.findElement(By.id("btn_submit")).click();
		driver.switchTo().defaultContent();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_contentFrame")));
		driver.switchTo().frame("ac_contentFrame");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ac_viewerFrame")));
		driver.switchTo().frame("ac_viewerFrame");
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("workInProgressImage")));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("//tr[@id='reportLinks']//a")));
		
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		
		
		
		}

}
