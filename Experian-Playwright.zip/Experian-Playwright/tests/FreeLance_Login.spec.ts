import{test, expect} from '@playwright/test'
import { HomePage } from '../Pages/HomePage';
import { LoginPage } from '../Pages/LoginPage';
import { CartPage } from '../Pages/CartPage';
import fs from 'fs'
import path from 'path'

const testdata = JSON.parse(fs.readFileSync(path.join(__dirname,"./data/LoginDetails.json"),'utf-8'));
for(const data of testdata){

test('FreeLance-Login', async({page})=>{

    await page.goto(data.Baseurl);
    const lp = new LoginPage(page);
    await lp.fillUsername(data.username);
    await lp.fillPassword(data.password);
    await lp.clickSignIn();
    await page.pause();
    
    const hp = new HomePage(page);
    await hp.selectCourse();
    await hp.clickCart();
    await expect(page).toHaveTitle('Learn Automation Courses');

    const cp = new CartPage(page);
    await cp.clickEnrollNow();
    await cp.typeAddress(data.Address);
    await cp.typePhoneNum(data.PhoneNum);
    await cp.clickEnrollbtn1();
    await cp.clickCancelBtn();
    

    
})}