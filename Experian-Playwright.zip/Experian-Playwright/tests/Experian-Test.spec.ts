import {test, expect} from '@playwright/test'
import fs from 'fs';
import path from 'path';

const testData = JSON.parse(fs.readFileSync(path.join(__dirname,"./data/RegistrationDetails.json"),'utf-8'));
for(const data of testData){
test("Experian employer service", async({page})=>{

    //Reading the data from Json file
    await page.goto(data.Url);
    await page.locator("//label[text()='First Name']//following::input[1]").fill(data.FirstName);
    await page.locator("//label[text()='Last Name']//following::input[1]").fill(data.LastName);
    await page.locator("//label[text()='Email Address']//following::input[1]").fill(data.EmailAddress);
    await page.locator("//label[text()='Street Address']//following::input[1]").fill(data.StreetAddress);
    await page.locator("//label[text()='City']//following::input[1]").fill(data.City);
    await page.locator("//label[text()='Zip Code']//following::input[1]").fill(data.ZipCode);
    await page.locator("#SurveyControl_SurveySubmit").click();

    //Since 'No' needs to select for all options, used for loop to select 'No' option
    const NoButton = await page.locator("//label[text()='No']").count();
    for(let i=0; i<NoButton; i++){
        await page.locator("//label[text()='No']").nth(i).click();
    }
    await page.locator("#SurveyControl_SurveySubmit").click();
    

    const confirmName = await page.locator("#hddVoterFirstName").getAttribute('value');
    console.log(confirmName);
    expect(confirmName).toContain(data.FirstName); //Verifiying the name provided above
    await page.locator("#SurveyControl_SurveySubmit").click();
   
    let pageUrl = page.url();
    expect (pageUrl).toContain("https://www.experian.com/employer-services/"); //Asserting the URL
    await page.waitForTimeout(3000);
    
})
}