import{test, expect} from '@playwright/test'
import { HomePage } from '../Pages/HomePage'
import { LoginPage } from '../Pages/LoginPage';

test("Login with Invalid creds", async({page})=>{
    await page.goto("https://freelance-learn-automation.vercel.app/login");
    const lp = new LoginPage(page);
    await lp.fillUsername("admin@email.com");
    await lp.fillPassword("admin@123222");
    await lp.clickSignIn();
    await page.waitForTimeout(3000);

    
})