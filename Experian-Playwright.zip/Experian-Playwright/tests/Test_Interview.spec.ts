import {test, expect} from '@playwright/test'

test('Identify the elements', async({page})=>{

    await page.goto("https://demowebshop.tricentis.com/");
   let categories = await page.locator("//div[@class='block block-category-navigation']/div/ul/li").allInnerTexts();
   console.log(categories);
    
   // await expect(categories).toBe(7);

    
    //console.log(categories.textContent());
    //await page.waitForTimeout(3000);
    
})