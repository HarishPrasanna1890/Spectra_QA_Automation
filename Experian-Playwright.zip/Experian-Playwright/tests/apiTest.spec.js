import{test, expect} from '@playwright/test'
var userID;

test("Open google", async({page, context})=>{

    await page.goto("https://www.google.com/");
    const newPage = await context.newPage();
    await newPage.goto("https://www.flipkart.com/");
    await page.pause();
    await page.bringToFront();

})

test("api test integration", async({request})=>{

    const GetRes = await request.get("https://reqres.in/api/users?page=2");
    console.log(await GetRes.json())
    expect(GetRes.status()).toBe(200);
})

test("Post request", async({request})=>{

    const PostRes = await request.post("https://reqres.in/api/users",
        {
            data:{"name":"Harish", "job":"God's Job"},
            headers:{"Accept":"application/json"}
        });
        console.log(await PostRes.json());
        expect(PostRes.status()).toBe(201);
        let response = await PostRes.json();
        userID = response.id
})

test.only("put request", async({request})=>{

    const PutResponse = await request.put("https://reqres.in/api/users/929",
        {
            data:{"name":"Harish Jancy", "job":"QA-Lead with God's help only"},
            headers:{"Accept":"application/json"}
        });
        console.log(await PutResponse.json());
        expect(PutResponse.status()).toBe(200);
        
})