import { Locator, Page} from "@playwright/test";
import { LoginPage } from "./LoginPage";
import { HomePage } from "./HomePage";

export class CartPage extends HomePage{

    page:Page;
    EnrollnowBtn: Locator;
    AddressField: Locator;
    PhoneNumField: Locator;
    EnrollNowBtn1: Locator;
    cancelBtn: Locator;

    constructor(page:Page){
        super(page)
        this.page=page;
        this.EnrollnowBtn = this.page.locator("//button[text()='Enroll Now']");
        this.AddressField = this.page.locator("#address");
        this.PhoneNumField = this.page.locator("#phone");
        this.EnrollNowBtn1 = this.page.locator("(//button[text()='Enroll Now'])[2]");
        this.cancelBtn = this.page.locator(".btn-close");
    }

    async clickEnrollNow(){
        await this.EnrollnowBtn.click();
    }

    async typeAddress(address:string){
        await this.AddressField.fill(address);
    }

    async typePhoneNum(phone:any){
        await this.PhoneNumField.fill(phone);
    }

    async clickEnrollbtn1(){
        await this.EnrollNowBtn1.click();
    }

    async clickCancelBtn(){
        await this.cancelBtn.click();
    }
}
