import { Locator, Page} from "@playwright/test";
import { LoginPage } from "./LoginPage";

export class HomePage extends LoginPage {
    
    page:Page;
    AddToCart: Locator;
    cartBtn: Locator;

    constructor(page:Page){
        super(page)
        this.page = page;
        this.AddToCart = this.page.locator("//div[@class='home-container']//div[3]//button");
        this.cartBtn = this.page.locator(".cartBtn")
    }

    async selectCourse(){
        await this.AddToCart.click();
    }

    async clickCart(){
        await this.cartBtn.click();
    }
} 





