import { Locator, Page } from "@playwright/test"

export class LoginPage{

    page:Page;
    enterUsername: Locator;
    enterPassword: Locator;
    signInbtn: Locator;

    constructor(page:Page){
        this.page = page;
        this.enterUsername = this.page.locator('#email1');
        this.enterPassword = this.page.locator('#password');
        this.signInbtn = this.page.locator("[type='submit']");
    }

    async fillUsername(uname:string){
        await this.enterUsername.fill(uname);
    }

    async fillPassword(pwd:string){
        await this.enterPassword.fill(pwd);
    }

    async clickSignIn(){
        await this.signInbtn.click();
    }
}


