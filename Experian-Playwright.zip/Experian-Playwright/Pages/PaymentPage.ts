import { Locator, Page } from "@playwright/test";
import { CartPage } from "./CartPage";

export class PaymentPage extends CartPage {

    paymentTab : Locator;
    paymentMent: Locator;
    paymentokBtn: Locator;

    constructor(page:Page){
        super(page);
        this.page = page;
        this.paymentTab = this.page.locator(".//");
        this.paymentMent = this.page.locator(".//");
        this.paymentokBtn = this.page.locator(".//");
    }

    async clickPaymentTab(){
        await this.paymentTab.fill("Test");
    }
    async clickPaymentMenu(){
        await this.paymentMent.fill("Harish");
    }
    async clickOkBtn(){
        await this.paymentokBtn.click();
    }
}

