import{test, expect} from '@playwright/test'

test("New window", async({page, context})=>{

    await page.goto("https://the-internet.herokuapp.com/windows");
    
    const newPage = context.waitForEvent('page');
    await page.locator("//a[text()='Click Here']").click();
    const newWindow = await newPage;
    console.log(newWindow.url());
})

test.only("Handling multiple windows", async({page, context})=>{

    await page.goto("https://www.leafground.com/window.xhtml")

    const [multitabs] = await Promise.all([
        await context.waitForEvent('page'),
        page.getByText("Open Multiple").click()
    ])

    const windows = multitabs.context().pages();
    console.log(windows.length);

})

test.only("Handle windows Interview", async({page,context})=>{

    await page.goto("https://the-internet.herokuapp.com/windows");
    const newPage =  context.waitForEvent('page');
    await page.locator("//a[text()='Click Here']").click();
    const newTab = await newPage;
    await page.waitForTimeout(2000);
    await page.bringToFront();
})