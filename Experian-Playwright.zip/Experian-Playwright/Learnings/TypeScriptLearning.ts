let names:string = "Harish"
let marks:number = 5000

let fName = "Anbarasu"
let marks1 = 2000

let empdetails:any[] =[1, "harish", true, null, undefined];

function add(a:number, b:number){
    return a+b;
}

//Using generics

let empname: Array<string>= ["Harish", "null" ]
let StudentDetails: Array<any> = [1, "Harish", null, true]

