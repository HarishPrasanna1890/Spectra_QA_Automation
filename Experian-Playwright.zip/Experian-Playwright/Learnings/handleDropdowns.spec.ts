import {test, expect} from '@playwright/test'

test('Handle dropdowns', async({page})=>{

    await page.goto("https://testautomationpractice.blogspot.com/");
    const colour = page.getByLabel("Colors:");
    await colour.scrollIntoViewIfNeeded(); // scolling down to the particular place
    await page.locator("#country").selectOption("France"); // dropdown option
    await page.selectOption("#colors",['Blue', 'Red', 'Yellow']); //multi select

    const colorOption = await page.$$("//select[@id='colors']/option");
    console.log('No of options:', colorOption.length)
    await expect(colorOption.length).toBe(5);
})