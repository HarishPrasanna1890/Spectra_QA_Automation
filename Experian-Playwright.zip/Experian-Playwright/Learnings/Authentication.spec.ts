import {test, expect} from '@playwright/test'

test("Authentication popup", async({page})=>{
    const username= 'admin';
    const password = 'admin';
    
    page.setExtraHTTPHeaders({Authorization : createAuthHeader(username, password)});
    await page.goto("https://the-internet.herokuapp.com/basic_auth");
})

function createAuthHeader(username:any, password:any){

    return 'Basic' +btoa(username+':'+password);
}